import { WalletProvider } from './wallet/WalletContext';
import { WalletPanel } from './components/WalletPanel';
import { ProfileForm } from './components/ProfileForm';
import { BountyForm } from './components/BountyForm';
import ggBountyLogo from './assets/gg-bounty-logo.png';

export default function App(): JSX.Element {
    return (
        <WalletProvider>
            <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
                <header
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 10,
                        padding: '12px 24px',
                        borderBottom: '1px solid var(--border-soft)'
                    }}
                >
                    <img src={ggBountyLogo} alt="GG Bounty" style={{ height: 30, width: 30, borderRadius: 6 }} />
                    <strong style={{ fontSize: 15, letterSpacing: '-0.01em' }}>GG Bounty</strong>
                    <span className="text-muted" style={{ fontSize: 12, marginLeft: 4 }}>
                        decentralized bounty marketplace on Canopy
                    </span>
                </header>

                <main
                    style={{
                        flex: 1,
                        display: 'flex',
                        flexWrap: 'wrap',
                        alignItems: 'flex-start',
                        justifyContent: 'center',
                        gap: 24,
                        padding: '48px 24px'
                    }}
                >
                    <WalletPanel />
                    <ProfileForm />
                    <BountyForm />
                </main>
            </div>
        </WalletProvider>
    );
}
