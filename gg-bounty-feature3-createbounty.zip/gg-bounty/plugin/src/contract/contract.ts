/* This file contains the base contract implementation that overrides the basic 'transfer' functionality */

import Long from 'long';
import { createHash } from 'node:crypto';

import { types } from '../proto/types.js';

import {
    IPluginError,
    ErrInsufficientFunds,
    ErrInvalidAddress,
    ErrInvalidAmount,
    ErrInvalidMessageCast,
    ErrTxFeeBelowStateLimit,
    ErrInvalidUsername,
    ErrBioTooLong,
    ErrAvatarUrlTooLong,
    ErrInvalidTitle,
    ErrInvalidDescription,
    ErrInvalidReward,
    ErrInvalidDeadline
} from './error.js';

import type { Plugin, Config } from './plugin.js';
import { JoinLenPrefix, FromAny, Unmarshal } from './plugin.js';
import { fileDescriptorProtos } from '../proto/descriptors.js';

// GG Bounty custom state prefixes (see "avoid prefix collisions" in TUTORIAL.md - Canopy
// reserves single-byte prefixes 1-15 for core state; GG Bounty uses 100+ for its own records).
const profilePrefix = Buffer.from([100]); // store key prefix for Profile records
const bountyPrefix = Buffer.from([101]); // store key prefix for Bounty records

// ESCROW_DOMAIN_TAG namespaces the escrow pseudo-address derivation so it can never collide
// with a real wallet address (which is sha256(publicKey)[:20] with no such tag) or with any
// other GG Bounty-derived address.
const ESCROW_DOMAIN_TAG = Buffer.from('gg-bounty-escrow-v1');

// deriveBountyId() computes a deterministic 20-byte bounty id from data every validator sees
// identically: the creator's address, the title, and the creating transaction's own time/height
// (both part of the SIGNED transaction, not local wall-clock - see the determinism note on
// DeliverMessageCreateProfile above). Never uses Math.random() or Date.now().
function deriveBountyId(creator: Uint8Array, title: string, txTime: Long, createdHeight: Long): Uint8Array {
    const timeBuf = Buffer.alloc(8);
    timeBuf.writeBigUInt64BE(BigInt(txTime.toString()));
    const heightBuf = Buffer.alloc(8);
    heightBuf.writeBigUInt64BE(BigInt(createdHeight.toString()));
    const preimage = Buffer.concat([Buffer.from(creator), Buffer.from(title, 'utf8'), timeBuf, heightBuf]);
    return createHash('sha256').update(preimage).digest().subarray(0, 20);
}

// deriveEscrowAddress() computes the deterministic pseudo-account address that holds a given
// bounty's escrowed reward. No private key exists for this address - only DeliverMessageCreateBounty
// and (later) DeliverMessageSelectWinner ever write to it, both server-side, so nothing but a
// valid signed CreateBounty/SelectWinner transaction can move funds in or out of it.
function deriveEscrowAddress(bountyId: Uint8Array): Uint8Array {
    const preimage = Buffer.concat([ESCROW_DOMAIN_TAG, Buffer.from(bountyId)]);
    return createHash('sha256').update(preimage).digest().subarray(0, 20);
}

// ContractConfig: the configuration of the contract
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const ContractConfig: any = {
    name: 'go_plugin_contract',
    id: 1,
    version: 1,
    supportedTransactions: ['send', 'createProfile', 'createBounty'],
    transactionTypeUrls: [
        'type.googleapis.com/types.MessageSend',
        'type.googleapis.com/types.MessageCreateProfile',
        'type.googleapis.com/types.MessageCreateBounty'
    ],
    eventTypeUrls: [],
    // custom record prefixes this plugin owns - see "avoid prefix collisions" in TUTORIAL.md.
    // Canopy reserves 1-15 for core state; GG Bounty allocates 100+ for its own records.
    // 100 = Profile, 101 = Bounty. Reserved for upcoming features: 102 = Participant,
    // 103 = Submission.
    customStatePrefixes: [profilePrefix, bountyPrefix],
    fileDescriptorProtos
};

// Contract() defines the smart contract that implements the extended logic of the nested chain
export class Contract {
    Config: Config;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    FSMConfig: any;
    plugin: Plugin;
    fsmId: Long;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    constructor(config: Config, fsmConfig: any, plugin: Plugin, fsmId: Long) {
        this.Config = config;
        this.FSMConfig = fsmConfig;
        this.plugin = plugin;
        this.fsmId = fsmId;
    }

    // Genesis() implements logic to import a json file to create the state at height 0 and export the state at any height
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
    Genesis(_request: any): any {
        return {}; // TODO map out original token holders
    }

    // BeginBlock() is code that is executed at the start of `applying` the block
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
    BeginBlock(_request: any): any {
        return {};
    }

    // EndBlock() is code that is executed at the end of 'applying' a block
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
    EndBlock(_request: any): any {
        return {};
    }

    // CheckMessageSend() statelessly validates a 'send' message
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    CheckMessageSend(msg: any): any {
        // check sender address
        if (!msg.fromAddress || msg.fromAddress.length !== 20) {
            return { error: ErrInvalidAddress() };
        }
        // check recipient address
        if (!msg.toAddress || msg.toAddress.length !== 20) {
            return { error: ErrInvalidAddress() };
        }
        // check amount
        const amount = msg.amount as Long | number | undefined;
        if (!amount || (Long.isLong(amount) ? amount.isZero() : amount === 0)) {
            return { error: ErrInvalidAmount() };
        }
        // return the authorized signers
        return {
            recipient: msg.toAddress,
            authorizedSigners: [msg.fromAddress]
        };
    }

    // CheckMessageCreateProfile() statelessly validates a 'createProfile' message
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    CheckMessageCreateProfile(msg: any): any {
        // check signer address
        if (!msg.signerAddress || msg.signerAddress.length !== 20) {
            return { error: ErrInvalidAddress() };
        }
        // check username: required, 1-32 characters (after trimming)
        const username = typeof msg.username === 'string' ? msg.username.trim() : '';
        if (username.length < 1 || username.length > 32) {
            return { error: ErrInvalidUsername() };
        }
        // check bio: optional, up to 280 characters
        const bio = typeof msg.bio === 'string' ? msg.bio : '';
        if (bio.length > 280) {
            return { error: ErrBioTooLong() };
        }
        // check avatarUrl: optional, up to 512 characters
        const avatarUrl = typeof msg.avatarUrl === 'string' ? msg.avatarUrl : '';
        if (avatarUrl.length > 512) {
            return { error: ErrAvatarUrlTooLong() };
        }
        // the profile owner (signer) is the sole authorized signer
        return {
            recipient: msg.signerAddress,
            authorizedSigners: [msg.signerAddress]
        };
    }

    // CheckMessageCreateBounty() statelessly validates a 'createBounty' message.
    // tx is passed so the deadline can be validated against the transaction's own (deterministic,
    // signed) time field rather than local wall-clock, consistent with the determinism
    // requirements documented on deriveBountyId()/DeliverMessageCreateProfile above.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    CheckMessageCreateBounty(msg: any, tx: any): any {
        // check signer address
        if (!msg.signerAddress || msg.signerAddress.length !== 20) {
            return { error: ErrInvalidAddress() };
        }
        // check title: required, 1-100 characters
        const title = typeof msg.title === 'string' ? msg.title.trim() : '';
        if (title.length < 1 || title.length > 100) {
            return { error: ErrInvalidTitle() };
        }
        // check description: required, 1-2000 characters
        const description = typeof msg.description === 'string' ? msg.description.trim() : '';
        if (description.length < 1 || description.length > 2000) {
            return { error: ErrInvalidDescription() };
        }
        // check reward: must be > 0
        const reward = Long.isLong(msg.reward) ? msg.reward : Long.fromNumber((msg.reward as number) || 0);
        if (reward.lessThanOrEqual(0)) {
            return { error: ErrInvalidReward() };
        }
        // check deadline: must be strictly after the transaction's own time (converted to seconds)
        const deadline = Long.isLong(msg.deadline)
            ? msg.deadline
            : Long.fromNumber((msg.deadline as number) || 0);
        const txTime = Long.isLong(tx?.time) ? tx.time : Long.fromNumber((tx?.time as number) || 0);
        const txTimeSeconds = txTime.divide(1_000_000);
        if (deadline.lessThanOrEqual(txTimeSeconds)) {
            return { error: ErrInvalidDeadline() };
        }
        // the creator (signer) is the sole authorized signer
        return {
            recipient: msg.signerAddress,
            authorizedSigners: [msg.signerAddress]
        };
    }
}

// Async versions of contract methods for proper state handling
export class ContractAsync {
    // CheckTx() is code that is executed to statelessly validate a transaction
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static async CheckTx(contract: Contract, request: any): Promise<any> {
        // validate fee
        const [resp, err] = await contract.plugin.StateRead(contract, {
            keys: [
                {
                    queryId: Long.fromNumber(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER)),
                    key: KeyForFeeParams()
                }
            ]
        });

        if (err) {
            return { error: err };
        }
        if (resp?.error) {
            return { error: resp.error };
        }

        // convert bytes into fee parameters
        const feeParamsBytes = resp?.results?.[0]?.entries?.[0]?.value;
        if (feeParamsBytes && feeParamsBytes.length > 0) {
            const [minFees, unmarshalErr] = Unmarshal(feeParamsBytes, types.FeeParams);
            if (unmarshalErr) {
                return { error: unmarshalErr };
            }
            // check for the minimum fee
            const txFee = request.tx?.fee as Long | number | undefined;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const sendFee = (minFees as any)?.sendFee as Long | number | undefined;
            if (txFee !== undefined && sendFee !== undefined) {
                const txFeeNum = Long.isLong(txFee) ? txFee.toNumber() : txFee;
                const sendFeeNum = Long.isLong(sendFee) ? sendFee.toNumber() : sendFee;
                if (txFeeNum < sendFeeNum) {
                    return { error: ErrTxFeeBelowStateLimit() };
                }
            }
        }

        // get the message and its type
        const [msg, msgType, msgErr] = FromAny(request.tx?.msg);
        if (msgErr) {
            return { error: msgErr };
        }
        // handle the message based on type
        if (msg) {
            switch (msgType) {
                case 'MessageSend':
                    return contract.CheckMessageSend(msg);
                case 'MessageCreateProfile':
                    return contract.CheckMessageCreateProfile(msg);
                case 'MessageCreateBounty':
                    return contract.CheckMessageCreateBounty(msg, request.tx);
                default:
                    return { error: ErrInvalidMessageCast() };
            }
        }
        return { error: ErrInvalidMessageCast() };
    }

    // DeliverTx() is code that is executed to apply a transaction
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static async DeliverTx(contract: Contract, request: any): Promise<any> {
        // get the message and its type
        const [msg, msgType, err] = FromAny(request.tx?.msg);
        if (err) {
            return { error: err };
        }
        // handle the message based on type
        if (msg) {
            switch (msgType) {
                case 'MessageSend':
                    return ContractAsync.DeliverMessageSend(contract, msg, request.tx?.fee as Long);
                case 'MessageCreateProfile':
                    return ContractAsync.DeliverMessageCreateProfile(contract, msg, request.tx?.time as Long);
                case 'MessageCreateBounty':
                    return ContractAsync.DeliverMessageCreateBounty(contract, msg, request.tx);
                default:
                    return { error: ErrInvalidMessageCast() };
            }
        }
        return { error: ErrInvalidMessageCast() };
    }

    // DeliverMessageSend() handles a 'send' message
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static async DeliverMessageSend(
        contract: Contract,
        msg: any,
        fee: Long | number | undefined
    ): Promise<any> {
        const fromQueryId = Long.fromNumber(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));
        const toQueryId = Long.fromNumber(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));
        const feeQueryId = Long.fromNumber(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));

        // calculate the from key and to key
        const fromKey = KeyForAccount(msg.fromAddress!);
        const toKey = KeyForAccount(msg.toAddress!);
        const feePoolKey = KeyForFeePool(Long.fromNumber(contract.Config.ChainId));

        // get the from and to account
        const [response, readErr] = await contract.plugin.StateRead(contract, {
            keys: [
                { queryId: feeQueryId, key: feePoolKey },
                { queryId: fromQueryId, key: fromKey },
                { queryId: toQueryId, key: toKey }
            ]
        });

        // check for internal error
        if (readErr) {
            return { error: readErr };
        }
        // ensure no error fsm error
        if (response?.error) {
            return { error: response.error };
        }

        // get the from bytes and to bytes
        let fromBytes: Uint8Array | null = null;
        let toBytes: Uint8Array | null = null;
        let feePoolBytes: Uint8Array | null = null;

        for (const resp of response?.results || []) {
            const qid = resp.queryId as Long;
            if (qid.equals(fromQueryId)) {
                fromBytes = resp.entries?.[0]?.value || null;
            } else if (qid.equals(toQueryId)) {
                toBytes = resp.entries?.[0]?.value || null;
            } else if (qid.equals(feeQueryId)) {
                feePoolBytes = resp.entries?.[0]?.value || null;
            }
        }

        // convert the bytes to account structures
        const [fromRaw, fromErr] = Unmarshal(fromBytes || new Uint8Array(), types.Account);
        if (fromErr) {
            return { error: fromErr };
        }
        const [toRaw, toErr] = Unmarshal(toBytes || new Uint8Array(), types.Account);
        if (toErr) {
            return { error: toErr };
        }
        const [feePoolRaw, feePoolErr] = Unmarshal(feePoolBytes || new Uint8Array(), types.Pool);
        if (feePoolErr) {
            return { error: feePoolErr };
        }

        // Cast to any for property access
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const from = fromRaw as any;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const to = toRaw as any;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const feePool = feePoolRaw as any;

        // add fee to 'amount to deduct'
        const msgAmount = Long.isLong(msg.amount)
            ? msg.amount
            : Long.fromNumber((msg.amount as number) || 0);
        const feeAmount = Long.isLong(fee) ? fee : Long.fromNumber((fee as number) || 0);
        const amountToDeduct = msgAmount.add(feeAmount);

        // get from amount
        const fromAmount = Long.isLong(from?.amount)
            ? from.amount
            : Long.fromNumber((from?.amount as number) || 0);

        // if the account amount is less than the amount to subtract; return insufficient funds
        if (fromAmount.lessThan(amountToDeduct)) {
            return { error: ErrInsufficientFunds() };
        }

        // for self-transfer, use same account data
        const isSelfTransfer = Buffer.from(fromKey).equals(Buffer.from(toKey));
        const toAccount = isSelfTransfer ? from : to;

        // get amounts as Long
        const newFromAmount = fromAmount.subtract(amountToDeduct);
        const toAmount = Long.isLong(toAccount?.amount)
            ? toAccount.amount
            : Long.fromNumber((toAccount?.amount as number) || 0);
        const newToAmount = toAmount.add(msgAmount);
        const poolAmount = Long.isLong(feePool?.amount)
            ? feePool.amount
            : Long.fromNumber((feePool?.amount as number) || 0);
        const newPoolAmount = poolAmount.add(feeAmount);

        // Update the accounts
        const updatedFrom = types.Account.create({ address: from?.address, amount: newFromAmount });
        const updatedTo = types.Account.create({
            address: toAccount?.address,
            amount: newToAmount
        });
        const updatedPool = types.Pool.create({ id: feePool?.id, amount: newPoolAmount });

        // convert the accounts to bytes
        const newFromBytes = types.Account.encode(updatedFrom).finish();
        const newToBytes = types.Account.encode(updatedTo).finish();
        const newFeePoolBytes = types.Pool.encode(updatedPool).finish();

        // execute writes to the database
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let writeResp: any;
        let writeErr: IPluginError | null;

        // if the from account is drained - delete the from account
        if (newFromAmount.isZero()) {
            [writeResp, writeErr] = await contract.plugin.StateWrite(contract, {
                sets: [
                    { key: feePoolKey, value: newFeePoolBytes },
                    { key: toKey, value: newToBytes }
                ],
                deletes: [{ key: fromKey }]
            });
        } else {
            [writeResp, writeErr] = await contract.plugin.StateWrite(contract, {
                sets: [
                    { key: feePoolKey, value: newFeePoolBytes },
                    { key: toKey, value: newToBytes },
                    { key: fromKey, value: newFromBytes }
                ]
            });
        }

        if (writeErr) {
            return { error: writeErr };
        }
        if (writeResp?.error) {
            return { error: writeResp.error };
        }

        return {};
    }

    // DeliverMessageCreateProfile() handles a 'createProfile' message: creates the profile if it
    // doesn't exist yet, or updates the editable fields (username/avatarUrl/bio) if it does -
    // preserving system-tracked fields (reputation, totalRewardsEarned, completedBounties,
    // createdBounties, createdAt), which only change as a side effect of other GG Bounty
    // transactions (SelectWinner, CreateBounty, etc. - later features).
    //
    // txTime is `request.tx.time` from DeliverTx (see tx.proto: "used as temporal entropy" - it
    // is part of the SIGNED transaction, so every validator sees the identical value). This is
    // used as the record's timestamp instead of the local machine's Date.now(), which would be
    // non-deterministic across validators and could produce diverging state roots. tx.time is in
    // MICROSECONDS (matches frontend/src/tx/buildTx.ts), so it's divided by 1e6 to store as
    // unix seconds, consistent with tx.proto's documented convention for created_height-adjacent
    // temporal fields.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static async DeliverMessageCreateProfile(contract: Contract, msg: any, txTime?: Long | number): Promise<any> {
        const profileQueryId = Long.fromNumber(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));
        const profileKey = KeyForProfile(msg.signerAddress!);

        // read any existing profile for this address
        const [response, readErr] = await contract.plugin.StateRead(contract, {
            keys: [{ queryId: profileQueryId, key: profileKey }]
        });
        if (readErr) {
            return { error: readErr };
        }
        if (response?.error) {
            return { error: response.error };
        }

        let existingBytes: Uint8Array | null = null;
        for (const resp of response?.results || []) {
            const qid = resp.queryId as Long;
            if (qid.equals(profileQueryId)) {
                existingBytes = resp.entries?.[0]?.value || null;
            }
        }

        const [existingRaw, unmarshalErr] = Unmarshal(existingBytes || new Uint8Array(), types.Profile);
        if (unmarshalErr) {
            return { error: unmarshalErr };
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const existing = existingRaw as any;
        const isNewProfile = !existingBytes || existingBytes.length === 0;

        const txTimeMicros = txTime ? Long.fromValue(txTime) : Long.ZERO;
        const nowSeconds = txTimeMicros.divide(1_000_000);

        const updatedProfile = types.Profile.create({
            address: msg.signerAddress,
            username: (msg.username as string).trim(),
            avatarUrl: (msg.avatarUrl as string) || '',
            bio: (msg.bio as string) || '',
            // system-tracked fields: preserved from the existing record, or zeroed for a new one
            reputation: isNewProfile ? Long.ZERO : existing?.reputation,
            totalRewardsEarned: isNewProfile ? Long.ZERO : existing?.totalRewardsEarned,
            completedBounties: isNewProfile ? Long.ZERO : existing?.completedBounties,
            createdBounties: isNewProfile ? Long.ZERO : existing?.createdBounties,
            createdAt: isNewProfile ? nowSeconds : existing?.createdAt,
            updatedAt: nowSeconds
        });

        const updatedProfileBytes = types.Profile.encode(updatedProfile).finish();

        const [writeResp, writeErr] = await contract.plugin.StateWrite(contract, {
            sets: [{ key: profileKey, value: updatedProfileBytes }]
        });
        if (writeErr) {
            return { error: writeErr };
        }
        if (writeResp?.error) {
            return { error: writeResp.error };
        }

        return {};
    }

    // DeliverMessageCreateBounty() handles a 'createBounty' message:
    //   1. debits `reward` uCNPY from the creator's account balance
    //   2. credits it to a deterministic, keyless escrow pseudo-account for this bounty id
    //      (see deriveEscrowAddress - only this plugin's code ever writes to it)
    //   3. writes the new Bounty record (status: Open)
    //   4. creates or updates the creator's Profile, incrementing createdBounties - this is the
    //      "side effect of other GG Bounty transactions" promised in DeliverMessageCreateProfile's
    //      docblock. If the creator has no profile yet, a minimal one is created (empty
    //      username/bio/avatar) so createdBounties has somewhere to live; the creator can fill in
    //      the rest later via CreateProfile, which preserves this count (see its upsert logic).
    //
    // tx is passed (not just msg) because deriveBountyId() needs tx.time and tx.createdHeight,
    // and DeliverMessageCreateProfile-style profile timestamps need tx.time - both must come from
    // the signed transaction, never local Date.now() (see the determinism note above).
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static async DeliverMessageCreateBounty(contract: Contract, msg: any, tx: any): Promise<any> {
        const txTime = Long.isLong(tx?.time) ? tx.time : Long.fromNumber((tx?.time as number) || 0);
        const createdHeight = Long.isLong(tx?.createdHeight)
            ? tx.createdHeight
            : Long.fromNumber((tx?.createdHeight as number) || 0);
        const nowSeconds = txTime.divide(1_000_000);

        const title = (msg.title as string).trim();
        const reward = Long.isLong(msg.reward) ? msg.reward : Long.fromNumber((msg.reward as number) || 0);

        const bountyId = deriveBountyId(msg.signerAddress!, title, txTime, createdHeight);
        const escrowAddress = deriveEscrowAddress(bountyId);

        const creatorAccountKey = KeyForAccount(msg.signerAddress!);
        const creatorProfileKey = KeyForProfile(msg.signerAddress!);
        const escrowAccountKey = KeyForAccount(escrowAddress);
        const bountyKey = KeyForBounty(bountyId);

        const creatorAccountQueryId = Long.fromNumber(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));
        const creatorProfileQueryId = Long.fromNumber(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));

        const [readResp, readErr] = await contract.plugin.StateRead(contract, {
            keys: [
                { queryId: creatorAccountQueryId, key: creatorAccountKey },
                { queryId: creatorProfileQueryId, key: creatorProfileKey }
            ]
        });
        if (readErr) {
            return { error: readErr };
        }
        if (readResp?.error) {
            return { error: readResp.error };
        }

        let creatorAccountBytes: Uint8Array | null = null;
        let creatorProfileBytes: Uint8Array | null = null;
        for (const resp of readResp?.results || []) {
            const qid = resp.queryId as Long;
            if (qid.equals(creatorAccountQueryId)) {
                creatorAccountBytes = resp.entries?.[0]?.value || null;
            } else if (qid.equals(creatorProfileQueryId)) {
                creatorProfileBytes = resp.entries?.[0]?.value || null;
            }
        }

        const [creatorAccountRaw, accountErr] = Unmarshal(creatorAccountBytes || new Uint8Array(), types.Account);
        if (accountErr) {
            return { error: accountErr };
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const creatorAccount = creatorAccountRaw as any;
        const creatorBalance = Long.isLong(creatorAccount?.amount)
            ? creatorAccount.amount
            : Long.fromNumber((creatorAccount?.amount as number) || 0);

        // re-validate solvency statefully - CheckMessageCreateBounty only validated reward > 0,
        // it has no access to the account balance (CheckTx in this template is stateless per
        // message, aside from the generic fee-threshold read at the top of CheckTx)
        if (creatorBalance.lessThan(reward)) {
            return { error: ErrInsufficientFunds() };
        }

        const [creatorProfileRaw, profileErr] = Unmarshal(creatorProfileBytes || new Uint8Array(), types.Profile);
        if (profileErr) {
            return { error: profileErr };
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const creatorProfile = creatorProfileRaw as any;
        const hasProfile = !!creatorProfileBytes && creatorProfileBytes.length > 0;

        const newCreatorBalance = creatorBalance.subtract(reward);
        const updatedCreatorAccount = types.Account.create({
            address: msg.signerAddress,
            amount: newCreatorBalance
        });
        const updatedEscrowAccount = types.Account.create({ address: escrowAddress, amount: reward });

        const updatedProfile = types.Profile.create({
            address: msg.signerAddress,
            username: hasProfile ? creatorProfile?.username : '',
            avatarUrl: hasProfile ? creatorProfile?.avatarUrl : '',
            bio: hasProfile ? creatorProfile?.bio : '',
            reputation: hasProfile ? creatorProfile?.reputation : Long.ZERO,
            totalRewardsEarned: hasProfile ? creatorProfile?.totalRewardsEarned : Long.ZERO,
            completedBounties: hasProfile ? creatorProfile?.completedBounties : Long.ZERO,
            createdBounties: (hasProfile ? creatorProfile?.createdBounties ?? Long.ZERO : Long.ZERO).add(1),
            createdAt: hasProfile ? creatorProfile?.createdAt : nowSeconds,
            updatedAt: nowSeconds
        });

        const newBounty = types.Bounty.create({
            id: bountyId,
            creator: msg.signerAddress,
            title,
            description: (msg.description as string).trim(),
            reward,
            deadline: msg.deadline,
            status: 0, // Open
            participantCount: Long.ZERO,
            submissionCount: Long.ZERO,
            winner: new Uint8Array(0),
            createdAt: nowSeconds
        });

        const sets = [
            { key: escrowAccountKey, value: types.Account.encode(updatedEscrowAccount).finish() },
            { key: creatorProfileKey, value: types.Profile.encode(updatedProfile).finish() },
            { key: bountyKey, value: types.Bounty.encode(newBounty).finish() }
        ];

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let writeResp: any;
        let writeErr: IPluginError | null;
        if (newCreatorBalance.isZero()) {
            [writeResp, writeErr] = await contract.plugin.StateWrite(contract, {
                sets,
                deletes: [{ key: creatorAccountKey }]
            });
        } else {
            [writeResp, writeErr] = await contract.plugin.StateWrite(contract, {
                sets: [...sets, { key: creatorAccountKey, value: types.Account.encode(updatedCreatorAccount).finish() }]
            });
        }
        if (writeErr) {
            return { error: writeErr };
        }
        if (writeResp?.error) {
            return { error: writeResp.error };
        }

        return {};
    }
}

const accountPrefix = Buffer.from([1]); // store key prefix for accounts
const poolPrefix = Buffer.from([2]); // store key prefix for pools
const paramsPrefix = Buffer.from([7]); // store key prefix for governance parameters

// KeyForAccount() returns the state database key for an account
export function KeyForAccount(addr: Uint8Array): Uint8Array {
    return JoinLenPrefix(accountPrefix, Buffer.from(addr));
}

// KeyForFeeParams() returns the state database key for governance controlled 'fee parameters'
export function KeyForFeeParams(): Uint8Array {
    return JoinLenPrefix(paramsPrefix, Buffer.from('/f/'));
}

// KeyForFeePool() returns the state database key for governance controlled 'fee parameters'
export function KeyForFeePool(chainId: Long): Uint8Array {
    return JoinLenPrefix(poolPrefix, formatUint64(chainId));
}

// KeyForProfile() returns the state database key for a GG Bounty Profile record
export function KeyForProfile(addr: Uint8Array): Uint8Array {
    return JoinLenPrefix(profilePrefix, Buffer.from(addr));
}

// ProfilePrefix() returns the bare prefix for range-reading all Profile records
export function ProfilePrefix(): Uint8Array {
    return JoinLenPrefix(profilePrefix);
}

// KeyForBounty() returns the state database key for a GG Bounty Bounty record
export function KeyForBounty(bountyId: Uint8Array): Uint8Array {
    return JoinLenPrefix(bountyPrefix, Buffer.from(bountyId));
}

// BountyPrefix() returns the bare prefix for range-reading all Bounty records
export function BountyPrefix(): Uint8Array {
    return JoinLenPrefix(bountyPrefix);
}

function formatUint64(u: Long): Buffer {
    const b = Buffer.alloc(8);
    b.writeBigUInt64BE(BigInt(u.toString()));
    return b;
}
